'use strict';

//var betterEndpoint = require('./BetterEndpoint.js');
var bestEndpoint = require('./BestEndpoint.js');

module.exports.endpoint = (event, context, callback) => {
    //var betterEndpoint = new BetterEndpoint;

    const response = {
        statusCode: 200,
        body: JSON.stringify(bestEndpoint.getCurrentTime(event)),
    };

    callback(null, response);
};
