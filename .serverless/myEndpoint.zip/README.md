# myEndpoint
simple lambda function using serverless framework to create API endpoint

handler.js

Contains the lambda function itself.  Note that all this function 
does is deal with the AWS event object handling.  For the business logic
it calls out to BestEndpoint object class

<BestEndpoint class="js">

</BestEndpoint>